#! /bin/bash

export PATH=/opt/anaconda3/bin:/opt/anaconda3/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin

python /Users/borisperezg/eclipsews/rebelapi/resources/textclassification.py "$@"