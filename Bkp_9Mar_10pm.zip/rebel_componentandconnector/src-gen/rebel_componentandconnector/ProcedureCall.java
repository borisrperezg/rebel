/**
 */
package rebel_componentandconnector;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Procedure Call</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see rebel_componentandconnector.Rebel_componentandconnectorPackage#getProcedureCall()
 * @model
 * @generated
 */
public interface ProcedureCall extends Connector {
} // ProcedureCall
