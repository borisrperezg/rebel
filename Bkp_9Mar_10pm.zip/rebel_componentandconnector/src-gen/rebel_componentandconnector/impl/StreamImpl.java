/**
 */
package rebel_componentandconnector.impl;

import org.eclipse.emf.ecore.EClass;

import rebel_componentandconnector.Rebel_componentandconnectorPackage;
import rebel_componentandconnector.Stream;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Stream</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class StreamImpl extends ConnectorImpl implements Stream {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StreamImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Rebel_componentandconnectorPackage.Literals.STREAM;
	}

} //StreamImpl
