/**
 */
package rebel_componentandconnector.impl;

import org.eclipse.emf.ecore.EClass;

import rebel_componentandconnector.Distributor;
import rebel_componentandconnector.Rebel_componentandconnectorPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Distributor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DistributorImpl extends ConnectorImpl implements Distributor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DistributorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Rebel_componentandconnectorPackage.Literals.DISTRIBUTOR;
	}

} //DistributorImpl
