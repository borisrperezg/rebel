/**
 */
package rebel_componentandconnector.impl;

import org.eclipse.emf.ecore.EClass;

import rebel_componentandconnector.Event;
import rebel_componentandconnector.Rebel_componentandconnectorPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EventImpl extends ConnectorImpl implements Event {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Rebel_componentandconnectorPackage.Literals.EVENT;
	}

} //EventImpl
