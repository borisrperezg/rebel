/**
 */
package rebel_componentandconnector.impl;

import org.eclipse.emf.ecore.EClass;

import rebel_componentandconnector.Adaptor;
import rebel_componentandconnector.Rebel_componentandconnectorPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Adaptor</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AdaptorImpl extends ConnectorImpl implements Adaptor {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AdaptorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Rebel_componentandconnectorPackage.Literals.ADAPTOR;
	}

} //AdaptorImpl
