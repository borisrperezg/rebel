/**
 */
package rebel_componentandconnector;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Distributor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see rebel_componentandconnector.Rebel_componentandconnectorPackage#getDistributor()
 * @model
 * @generated
 */
public interface Distributor extends Connector {
} // Distributor
